﻿var toHiglightRow;

function sendPostFlights(files) {
    let curr_url = 'api/index/planes';
    console.log(files);
    $.ajax({
        url: curr_url,
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json; charset=utf-8',
        data: files,
        success: function (data) {    
            var t = JSON.parse(data);
            console.log(t);
            addFlights(t);
            makeTable(t);
        }
        });
}


function makeTable(planesArray) {
    let table = document.getElementById('external-filghts-table');
    addRows(planesArray, table);
};

function addRow(row, plane) {

    console.log(plane);
    let j = 0; let cell = row.insertCell(0);
    cell.innerHTML = plane.FlightId;
    cell = row.insertCell(++j);
    cell.innerHTML = plane.CompanyName;
    cell = row.insertCell(++j);
    cell.innerHTML = "(" + plane.PlaneLocation.Longitude + ", " + plane.PlaneLocation.Latitude + ")";
    cell = row.insertCell(++j);
    cell.innerHTML = plane.Passengers;
    cell = row.insertCell(++j);
    cell.innerHTML = plane.PlaneLocation.Date_time;
};

//add rows to table
function addRows(planes,table) {
    let i;
    for (i = 0; i < planes.length; i++) {
        let plane = planes[i];
        let row = table.insertRow(table.rows.length);
        row.setAttribute("id", "external-row-" + plane.FlightId);
        /*row.on('click', function (e) {
            clickOnRow(plane);
        });*/
        addRow(row, plane);
    }

};

function highlightExternalRow(plane) {
    let id = plane.FlightId;
    if (toHiglightRow != undefined) {
        toHiglightRow.className = "";
        toHiglightRow = undefined;
    }
    let cName = "external-row-" + id;
    toHiglightRow = document.getElementById(cName);
    console.log(id);
    if (toHiglightRow == undefined) {
        return;
    }
    toHiglightRow.className = "highlightedRow";
    toHiglightRow.scrollIntoView();
    detailTable(plane);
    return toHiglightRow;
}

function clickOnRow(r) {
    let icon = document.getElementById("marker_" + r.FlightId);
    console.log(icon);
    //icon.openOn();
    highlightExternalRow(r);
}

function calculateTime(plane, time) {
    //2018-12-15T15:26:51Z
    let t = plane.PlaneLocation.Date_time;
    console.log(t);
    let d = new Date(t);
    //let d = Date.parse(plane.PlaneLocation.Date_time);
    console.log(d);
    d.setSeconds(d.getSeconds + time);
    return d;

}

function detailTable(plane) {
    let id = plane.FlightId;
    let table = document.getElementById("details-filghts-table");
    if (table == undefined) {
        return;
    }
    if (table.rows.length > 1) {
        table.deleteRow(1);
    }
    let r = table.insertRow(table.rows.length);
    console.log(r);
    let cell = r.insertCell(0);
    cell.innerHTML = "airways";
    cell = r.insertCell(0);
    let segments = plane.Segments;
    let time = 0; let i = 0;
    for (i = 0; i < segments.length; i++) {
        time += segments[i].Timespan_seconds;
    }
    let t = calculateTime(plane, time);
    cell.innerHTML = t;
    cell = r.insertCell(0);
    cell.innerHTML = id;

}

function removeHighlightExternalRow() {

    toHiglightRow.className = "";
    return toHiglightRow;
}

(function () {
    "use strict";
    let dropZone = document.getElementById('drop-zone');
    let externalFlights = document.getElementById('externalFlights');
    let externalClass = 'well externalFlights'; let hidden = 'hidden';
    var startUpload = function (files) {
        let file = files[0]; let fr = new FileReader();
        fr.onload = function () {
            sendPostFlights(fr.result);
        }
        fr.readAsText(file);
    };
    externalFlights.ondragover = function () {
        document.getElementById('externalFlightsText').className = hidden;
        dropZone.className = 'upload-console-drop';
        return false;
    };

    externalFlights.ondragleave = function () {
        //this.className = externalClass;
        //document.getElementById('externalFlightsText').className = 'well inner';
        //dropZone.className = hidden;
        return false;
    };

    //drop functionallity
    dropZone.ondrop = function (e) {
        e.preventDefault();
        //this.className = 'upload-console-drop';
        document.getElementById('externalFlightsText').className = 'well inner';
        dropZone.className = hidden;
        startUpload(e.dataTransfer.files);
        console.log(e.dataTransfer.files);

        
 
    };

    dropZone.ondragover = function () {
        this.className = 'upload-console-drop drop';
        return false;
    };
    dropZone.ondragleave = function () {
        this.className = 'upload-console-drop';
        return false;
    };

}());