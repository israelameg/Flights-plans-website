﻿var planeIcon = L.icon({
    iconUrl: 'design/airplane.png',
    iconSize: [30, 30] // size of the icon
    //iconAnchor: [22, 94], // point of the icon which will correspond to marker's location
    //popupAnchor: [-3, -76]  // point from which the popup should open relative to the iconAnchor
});
var flights = new Map();
var poly;
var map;


function addMap() {
    //add the map
    map = L.map('mapid').setView([51.505, -0.09], 5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

}
//load the map when open the web
window.addEventListener("load", addMap);

function addFlights(data) {
    data.forEach(element => addPlaneIcon(element));
}

function getMessage(plane) {
    var msg = "";
    msg += "Passengers: ";
    msg += plane.Passengers;
    //msg
    return msg;

}
function drawLine(p) {
    if (poly != undefined) {
        map.removeControl(poly);
        poly = undefined;
    }
    var segments = p.Segments; let lat; let lng;
    var locations = [];
    locations.push([p.PlaneLocation.Latitude, p.PlaneLocation.Longitude])
    let i = 0;
    for (i = 0; i < segments.length; i++) {
        let element = segments[i];
        lat = element.Latitude;
        lng = element.Longitude;
        locations.push([lat, lng]);
    }

    poly = L.polyline(locations).addTo(map);
}


function addPlaneIcon(plane) {
    //lat,lng
    if (plane == undefined) {
        console.log("plane == undefined");
        return;
    }
    var location = [plane.PlaneLocation.Latitude, plane.PlaneLocation.Longitude];
    var mark = L.marker(location, { icon: planeIcon }).addTo(map);
    mark.bindPopup(getMessage(plane));
    mark._icon.id = "marker_" + plane.FlightId;
    flights.set(plane.FlightId, plane);
    mark.on('click', function (e) {
        p = flights.get(plane.FlightId)
        drawLine(p);
        highlightExternalRow(p);
    });

}